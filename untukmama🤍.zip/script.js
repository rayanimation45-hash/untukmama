window.onload = function () {

    const envelope = document.getElementById("envelope");

    if (envelope) {
        envelope.addEventListener("click", function () {
            envelope.classList.toggle("open");
        });
    }

    // ⭐ GENERATE BINTANG
    const starsContainer = document.querySelector(".stars");

    for (let i = 0; i < 80; i++) {
        const star = document.createElement("div");
        star.classList.add("star");

        // posisi random
        star.style.left = Math.random() * 100 + "vw";

        // ukuran random
        let size = Math.random() * 3 + 1;
        star.style.width = size + "px";
        star.style.height = size + "px";

        // animasi random biar natural
        star.style.animationDuration =
            (Math.random() * 5 + 5) + "s, 2s";

        starsContainer.appendChild(star);
    }
};